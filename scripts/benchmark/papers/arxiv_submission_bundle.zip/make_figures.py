import matplotlib as mpl
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

# Figure 1: architecture
fig, ax = plt.subplots(figsize=(10.5, 5.8))
ax.set_xlim(0, 10)
ax.set_ylim(0, 6)
ax.axis('off')

# Main process boxes
boxes = {
    'md': (0.5, 3.6, 2.0, 1.0, 'Market data\nprocess (md)'),
    'strategy': (4.0, 3.6, 2.0, 1.0, 'Native C++\nstrategy'),
    'td': (7.5, 3.6, 2.0, 1.0, 'Trade process\n(td / mock TD)'),
    'master': (1.2, 0.7, 2.0, 0.8, 'Master'),
    'ledger': (6.8, 0.7, 2.0, 0.8, 'Ledger'),
}

for x, y, w, h, label in boxes.values():
    p = FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.04,rounding_size=0.08',
                       linewidth=1.2, facecolor='white')
    ax.add_patch(p)
    ax.text(x + w/2, y + h/2, label, ha='center', va='center', fontsize=10)

# Journal bus
journal = FancyBboxPatch((0.9, 2.15), 8.2, 0.75, boxstyle='round,pad=0.03,rounding_size=0.08',
                         linewidth=1.4, facecolor='white')
ax.add_patch(journal)
ax.text(5.0, 2.525, 'Journal-based shared-memory event path and persistent event record',
        ha='center', va='center', fontsize=10.5, fontweight='bold')

# Vertical connections
for x in [1.5, 5.0, 8.5]:
    ax.add_patch(FancyArrowPatch((x, 3.6), (x, 2.9), arrowstyle='<->', mutation_scale=12, linewidth=1.1))
for x in [2.2, 7.8]:
    ax.add_patch(FancyArrowPatch((x, 1.5), (x, 2.15), arrowstyle='<->', mutation_scale=12, linewidth=1.1))

# Logical event flow labels
ax.add_patch(FancyArrowPatch((2.5, 4.1), (4.0, 4.1), arrowstyle='->', mutation_scale=12, linewidth=1.2))
ax.text(3.25, 4.35, r'Depth  ($t_{depth}^{gen}$)', ha='center', va='bottom', fontsize=9)
ax.add_patch(FancyArrowPatch((6.0, 4.1), (7.5, 4.1), arrowstyle='->', mutation_scale=12, linewidth=1.2))
ax.text(6.75, 4.35, r'OrderInput  ($t_{input}^{gen}$)', ha='center', va='bottom', fontsize=9)
ax.add_patch(FancyArrowPatch((9.5, 3.9), (9.5, 3.0), arrowstyle='->', mutation_scale=12, linewidth=1.2))
ax.text(9.65, 3.45, r'Local OrderReport\n($t_{report}^{gen}$)', ha='left', va='center', fontsize=9)

ax.text(5.0, 5.35, 'Measured local software path', ha='center', va='center', fontsize=12, fontweight='bold')
ax.text(5.0, 1.78, 'All measured timestamps are journal frame generation times on one host',
        ha='center', va='center', fontsize=9, style='italic')
ax.text(5.0, 0.2, 'External network, exchange gateway, matching engine, queue position, and fills are excluded',
        ha='center', va='center', fontsize=9)
fig.tight_layout()
fig.savefig('/mnt/data/arxiv_submission/figures/architecture.pdf', bbox_inches='tight')
fig.savefig('/mnt/data/arxiv_submission/figures/architecture.png', dpi=200, bbox_inches='tight')
plt.close(fig)

# Figure 2: run-level percentiles
runs = np.arange(1, 6)
p50 = np.array([125.312, 121.088, 121.344, 121.216, 135.424])
p90 = np.array([296.2176, 256.0, 281.3696, 257.8176, 298.624])
p99 = np.array([447.42912, 438.07488, 662.03136, 434.78784, 447.2832])

fig, ax = plt.subplots(figsize=(8.6, 4.8))
ax.plot(runs, p50, marker='o', label='p50')
ax.plot(runs, p90, marker='o', label='p90')
ax.plot(runs, p99, marker='o', label='p99')
ax.set_xlabel('Benchmark run')
ax.set_ylabel('Depth-to-local-order-report latency (microseconds)')
ax.set_xticks(runs)
ax.grid(True, alpha=0.25)
ax.legend(frameon=False, ncol=3, loc='upper left')
ax.set_ylim(0, 720)
fig.tight_layout()
fig.savefig('/mnt/data/arxiv_submission/figures/latency_by_run.pdf', bbox_inches='tight')
fig.savefig('/mnt/data/arxiv_submission/figures/latency_by_run.png', dpi=200, bbox_inches='tight')
plt.close(fig)
